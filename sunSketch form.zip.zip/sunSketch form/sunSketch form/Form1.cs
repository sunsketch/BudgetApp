﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sunSketch_form
{
    public partial class budjetForm : Form
    {
        public budjetForm()
        {
            InitializeComponent();
        }

        private void housingBtn_Click(object sender, EventArgs e)
        {

        }

        private void transportBtn_Click(object sender, EventArgs e)
        {

        }

        private void foodBtn_Click(object sender, EventArgs e)
        {

        }

        private void utilitiesBtn_Click(object sender, EventArgs e)
        {

        }

        private void healthBtn_Click(object sender, EventArgs e)
        {

        }

        private void entertainmentBtn_Click(object sender, EventArgs e)
        {

        }

        private void educationBtn_Click(object sender, EventArgs e)
        {

        }

        private void savingsBtn_Click(object sender, EventArgs e)
        {

        }

        private void debtsBtn_Click(object sender, EventArgs e)
        {

        }

        private void personalcareBtn_Click(object sender, EventArgs e)
        {

        }

        private void clothingBtn_Click(object sender, EventArgs e)
        {

        }

        private void giftsBtn_Click(object sender, EventArgs e)
        {

        }

        private void travelBtn_Click(object sender, EventArgs e)
        {

        }

        private void taxesBtn_Click(object sender, EventArgs e)
        {

        }

        private void miscBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
