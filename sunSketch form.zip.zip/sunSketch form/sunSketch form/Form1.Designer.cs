﻿
namespace sunSketch_form
{
    partial class budjetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.healthBtn = new System.Windows.Forms.Button();
            this.utilitiesBtn = new System.Windows.Forms.Button();
            this.foodBtn = new System.Windows.Forms.Button();
            this.transportBtn = new System.Windows.Forms.Button();
            this.housingBtn = new System.Windows.Forms.Button();
            this.personalcareBtn = new System.Windows.Forms.Button();
            this.debtsBtn = new System.Windows.Forms.Button();
            this.savingsBtn = new System.Windows.Forms.Button();
            this.educationBtn = new System.Windows.Forms.Button();
            this.entertainmentBtn = new System.Windows.Forms.Button();
            this.clothingBtn = new System.Windows.Forms.Button();
            this.giftsBtn = new System.Windows.Forms.Button();
            this.travelBtn = new System.Windows.Forms.Button();
            this.taxesBtn = new System.Windows.Forms.Button();
            this.miscBtn = new System.Windows.Forms.Button();
            this.viewStatsBtn = new System.Windows.Forms.Button();
            this.homeBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // healthBtn
            // 
            this.healthBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.healthBtn.Location = new System.Drawing.Point(1711, 358);
            this.healthBtn.Name = "healthBtn";
            this.healthBtn.Size = new System.Drawing.Size(120, 106);
            this.healthBtn.TabIndex = 4;
            this.healthBtn.Text = "Healthcare";
            this.healthBtn.UseVisualStyleBackColor = true;
            this.healthBtn.Click += new System.EventHandler(this.healthBtn_Click);
            // 
            // utilitiesBtn
            // 
            this.utilitiesBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.utilitiesBtn.Location = new System.Drawing.Point(1324, 358);
            this.utilitiesBtn.Name = "utilitiesBtn";
            this.utilitiesBtn.Size = new System.Drawing.Size(120, 106);
            this.utilitiesBtn.TabIndex = 3;
            this.utilitiesBtn.Text = "Utilities";
            this.utilitiesBtn.UseVisualStyleBackColor = true;
            this.utilitiesBtn.Click += new System.EventHandler(this.utilitiesBtn_Click);
            // 
            // foodBtn
            // 
            this.foodBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodBtn.Location = new System.Drawing.Point(928, 358);
            this.foodBtn.Name = "foodBtn";
            this.foodBtn.Size = new System.Drawing.Size(120, 106);
            this.foodBtn.TabIndex = 2;
            this.foodBtn.Text = "Food";
            this.foodBtn.UseVisualStyleBackColor = true;
            this.foodBtn.Click += new System.EventHandler(this.foodBtn_Click);
            // 
            // transportBtn
            // 
            this.transportBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transportBtn.Location = new System.Drawing.Point(546, 358);
            this.transportBtn.Name = "transportBtn";
            this.transportBtn.Size = new System.Drawing.Size(120, 106);
            this.transportBtn.TabIndex = 1;
            this.transportBtn.Text = "Tranportation";
            this.transportBtn.UseVisualStyleBackColor = true;
            this.transportBtn.Click += new System.EventHandler(this.transportBtn_Click);
            // 
            // housingBtn
            // 
            this.housingBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.housingBtn.Location = new System.Drawing.Point(177, 358);
            this.housingBtn.Name = "housingBtn";
            this.housingBtn.Size = new System.Drawing.Size(120, 106);
            this.housingBtn.TabIndex = 0;
            this.housingBtn.Text = "Housing ";
            this.housingBtn.UseVisualStyleBackColor = true;
            this.housingBtn.Click += new System.EventHandler(this.housingBtn_Click);
            // 
            // personalcareBtn
            // 
            this.personalcareBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personalcareBtn.Location = new System.Drawing.Point(1711, 522);
            this.personalcareBtn.Name = "personalcareBtn";
            this.personalcareBtn.Size = new System.Drawing.Size(120, 106);
            this.personalcareBtn.TabIndex = 9;
            this.personalcareBtn.Text = "Personal Care";
            this.personalcareBtn.UseVisualStyleBackColor = true;
            this.personalcareBtn.Click += new System.EventHandler(this.personalcareBtn_Click);
            // 
            // debtsBtn
            // 
            this.debtsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debtsBtn.Location = new System.Drawing.Point(1324, 522);
            this.debtsBtn.Name = "debtsBtn";
            this.debtsBtn.Size = new System.Drawing.Size(120, 106);
            this.debtsBtn.TabIndex = 8;
            this.debtsBtn.Text = "Debts";
            this.debtsBtn.UseVisualStyleBackColor = true;
            this.debtsBtn.Click += new System.EventHandler(this.debtsBtn_Click);
            // 
            // savingsBtn
            // 
            this.savingsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savingsBtn.Location = new System.Drawing.Point(928, 522);
            this.savingsBtn.Name = "savingsBtn";
            this.savingsBtn.Size = new System.Drawing.Size(120, 106);
            this.savingsBtn.TabIndex = 7;
            this.savingsBtn.Text = "Savings";
            this.savingsBtn.UseVisualStyleBackColor = true;
            this.savingsBtn.Click += new System.EventHandler(this.savingsBtn_Click);
            // 
            // educationBtn
            // 
            this.educationBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.educationBtn.Location = new System.Drawing.Point(546, 522);
            this.educationBtn.Name = "educationBtn";
            this.educationBtn.Size = new System.Drawing.Size(120, 106);
            this.educationBtn.TabIndex = 6;
            this.educationBtn.Text = "Education";
            this.educationBtn.UseVisualStyleBackColor = true;
            this.educationBtn.Click += new System.EventHandler(this.educationBtn_Click);
            // 
            // entertainmentBtn
            // 
            this.entertainmentBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entertainmentBtn.Location = new System.Drawing.Point(177, 522);
            this.entertainmentBtn.Name = "entertainmentBtn";
            this.entertainmentBtn.Size = new System.Drawing.Size(120, 106);
            this.entertainmentBtn.TabIndex = 5;
            this.entertainmentBtn.Text = "Entertainment ";
            this.entertainmentBtn.UseVisualStyleBackColor = true;
            this.entertainmentBtn.Click += new System.EventHandler(this.entertainmentBtn_Click);
            // 
            // clothingBtn
            // 
            this.clothingBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clothingBtn.Location = new System.Drawing.Point(177, 702);
            this.clothingBtn.Name = "clothingBtn";
            this.clothingBtn.Size = new System.Drawing.Size(120, 106);
            this.clothingBtn.TabIndex = 10;
            this.clothingBtn.Text = "Clothing and Accessories";
            this.clothingBtn.UseVisualStyleBackColor = true;
            this.clothingBtn.Click += new System.EventHandler(this.clothingBtn_Click);
            // 
            // giftsBtn
            // 
            this.giftsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.giftsBtn.Location = new System.Drawing.Point(546, 702);
            this.giftsBtn.Name = "giftsBtn";
            this.giftsBtn.Size = new System.Drawing.Size(120, 106);
            this.giftsBtn.TabIndex = 11;
            this.giftsBtn.Text = "Gifts and Donations";
            this.giftsBtn.UseVisualStyleBackColor = true;
            this.giftsBtn.Click += new System.EventHandler(this.giftsBtn_Click);
            // 
            // travelBtn
            // 
            this.travelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.travelBtn.Location = new System.Drawing.Point(928, 702);
            this.travelBtn.Name = "travelBtn";
            this.travelBtn.Size = new System.Drawing.Size(120, 106);
            this.travelBtn.TabIndex = 12;
            this.travelBtn.Text = "Travel ";
            this.travelBtn.UseVisualStyleBackColor = true;
            this.travelBtn.Click += new System.EventHandler(this.travelBtn_Click);
            // 
            // taxesBtn
            // 
            this.taxesBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxesBtn.Location = new System.Drawing.Point(1324, 702);
            this.taxesBtn.Name = "taxesBtn";
            this.taxesBtn.Size = new System.Drawing.Size(120, 106);
            this.taxesBtn.TabIndex = 13;
            this.taxesBtn.Text = "Taxes";
            this.taxesBtn.UseVisualStyleBackColor = true;
            this.taxesBtn.Click += new System.EventHandler(this.taxesBtn_Click);
            // 
            // miscBtn
            // 
            this.miscBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miscBtn.Location = new System.Drawing.Point(1711, 702);
            this.miscBtn.Name = "miscBtn";
            this.miscBtn.Size = new System.Drawing.Size(120, 106);
            this.miscBtn.TabIndex = 14;
            this.miscBtn.Text = " ";
            this.miscBtn.UseVisualStyleBackColor = true;
            this.miscBtn.Click += new System.EventHandler(this.miscBtn_Click);
            // 
            // viewStatsBtn
            // 
            this.viewStatsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewStatsBtn.Location = new System.Drawing.Point(997, 915);
            this.viewStatsBtn.Name = "viewStatsBtn";
            this.viewStatsBtn.Size = new System.Drawing.Size(104, 47);
            this.viewStatsBtn.TabIndex = 15;
            this.viewStatsBtn.Text = "View Stats";
            this.viewStatsBtn.UseVisualStyleBackColor = true;
            // 
            // homeBtn
            // 
            this.homeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.Location = new System.Drawing.Point(866, 915);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(104, 47);
            this.homeBtn.TabIndex = 16;
            this.homeBtn.Text = " Home";
            this.homeBtn.UseVisualStyleBackColor = true;
            this.homeBtn.Visible = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(174, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1654, 84);
            this.label1.TabIndex = 17;
            this.label1.Text = "Select a category";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // budjetForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2083, 1004);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.viewStatsBtn);
            this.Controls.Add(this.miscBtn);
            this.Controls.Add(this.taxesBtn);
            this.Controls.Add(this.travelBtn);
            this.Controls.Add(this.giftsBtn);
            this.Controls.Add(this.clothingBtn);
            this.Controls.Add(this.entertainmentBtn);
            this.Controls.Add(this.educationBtn);
            this.Controls.Add(this.savingsBtn);
            this.Controls.Add(this.debtsBtn);
            this.Controls.Add(this.personalcareBtn);
            this.Controls.Add(this.housingBtn);
            this.Controls.Add(this.transportBtn);
            this.Controls.Add(this.foodBtn);
            this.Controls.Add(this.utilitiesBtn);
            this.Controls.Add(this.healthBtn);
            this.Name = "budjetForm";
            this.Text = "Budjet builder ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button healthBtn;
        private System.Windows.Forms.Button utilitiesBtn;
        private System.Windows.Forms.Button foodBtn;
        private System.Windows.Forms.Button transportBtn;
        private System.Windows.Forms.Button housingBtn;
        private System.Windows.Forms.Button personalcareBtn;
        private System.Windows.Forms.Button debtsBtn;
        private System.Windows.Forms.Button savingsBtn;
        private System.Windows.Forms.Button educationBtn;
        private System.Windows.Forms.Button entertainmentBtn;
        private System.Windows.Forms.Button clothingBtn;
        private System.Windows.Forms.Button giftsBtn;
        private System.Windows.Forms.Button travelBtn;
        private System.Windows.Forms.Button taxesBtn;
        private System.Windows.Forms.Button miscBtn;
        private System.Windows.Forms.Button viewStatsBtn;
        private System.Windows.Forms.Button homeBtn;
        private System.Windows.Forms.Label label1;
    }
}

